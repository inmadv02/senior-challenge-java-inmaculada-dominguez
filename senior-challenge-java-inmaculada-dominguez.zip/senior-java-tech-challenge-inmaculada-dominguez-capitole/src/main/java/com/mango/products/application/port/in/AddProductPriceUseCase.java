package com.mango.products.application.port.in;

import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.PricedProduct;
import com.mango.products.domain.model.Product;

/**
 * Use case for adding a price to an existing product.
 */
public interface AddProductPriceUseCase {

    /**
     * Changes the price of an existing product.
     *
     * @param productId the ID of the {@link Product}  to change the price for
     * @param price     the new price to set for the product
     * @return the updated priced product with the new price
     */
    PricedProduct changeProductPrice(final Long productId, final Price price);
}
