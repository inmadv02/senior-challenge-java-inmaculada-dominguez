package com.mango.products.application.port.in;

import com.mango.products.domain.model.Product;

/**
 * Use case for creating a new product in the system.
 */
public interface CreateProductUseCase {

    /**
     * Creates a new product based on the provided {@link Product}  details.
     *
     * @param product The {@link Product}  details to create.
     * @return The created product with any additional information (e.g., generated ID).
     */
    Product createNewProduct(final Product product);
}
