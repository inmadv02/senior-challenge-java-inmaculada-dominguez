package com.mango.products.application.port.in;

import com.mango.products.domain.model.Product;

import java.time.LocalDate;

/**
 * Use case for retrieving the price record of a product.
 */
public interface GetProductPriceRecordUseCase {

    /**
     * Retrieves the price record of a {@link Product}  by its ID.
     *
     * @param productId the ID of the {@link Product}
     * @return the product with its price record
     */
    Product getProductPriceRecord(final Long productId);
}
