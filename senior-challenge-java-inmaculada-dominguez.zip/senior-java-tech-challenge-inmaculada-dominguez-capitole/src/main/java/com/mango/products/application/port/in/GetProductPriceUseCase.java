package com.mango.products.application.port.in;

import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.PricedProduct;
import com.mango.products.domain.model.Product;

import java.time.LocalDate;

/**
 * Use case for retrieving the price of a product on a specific date.
 */
public interface GetProductPriceUseCase {

    /**
     * Retrieves the price of a product for a given date.
     *
     * @param productId the ID of the {@link Product}
     * @param date      the date for which to retrieve the price
     * @return the {@link Price} of the {@link Product}  on the specified date
     */
    Price getProductPrice(final Long productId, final LocalDate date);
}
