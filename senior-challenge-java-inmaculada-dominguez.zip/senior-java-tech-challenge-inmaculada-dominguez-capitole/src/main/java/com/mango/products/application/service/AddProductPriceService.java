package com.mango.products.application.service;

import com.mango.products.application.port.in.AddProductPriceUseCase;
import com.mango.products.application.port.out.AddProductPricePort;
import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.PricedProduct;
import com.mango.products.domain.model.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Service implementation for adding a price to an existing product. It uses the AddProductPricePort to interact with the persistence layer.
 */
@Service
@RequiredArgsConstructor
public class AddProductPriceService implements AddProductPriceUseCase {

    private final AddProductPricePort repositoryPort;

    /**
     * Adds a new price to the product with the specified ID. It retrieves the product, adds the price, and saves the updated product.
     *
     * @param id    The ID of the {@link Product} to which the price will be added.
     * @param price The price to be added to the product.
     * @return The updated product with the new price included.
     */
    @Override
    public PricedProduct changeProductPrice(final Long id, final Price price) {
        return this.repositoryPort.addProductPrice(id, price);
    }
}
