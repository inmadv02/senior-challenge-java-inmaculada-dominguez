package com.mango.products.application.service;

import com.mango.products.application.port.in.CreateProductUseCase;
import com.mango.products.application.port.out.CreateProductPort;
import com.mango.products.domain.model.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Service responsible for handling the creation of new products.
 * It implements the CreateProductUseCase interface and uses the CreateProductPort to persist the product data.
 */
@Service
@RequiredArgsConstructor
public class CreateProductService implements CreateProductUseCase {

    private final CreateProductPort repositoryPort;

    /**
     * Creates a new product by delegating the persistence to the CreateProductPort.
     *
     * @param product The {@link Product} to be created.
     * @return The created product with any additional information (e.g., generated ID).
     */
    @Override
    public Product createNewProduct(final Product product) {
        return this.repositoryPort.saveProduct(product);
    }
}
