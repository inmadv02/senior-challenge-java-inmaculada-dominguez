package com.mango.products.application.service;

import com.mango.products.application.port.in.GetProductPriceRecordUseCase;
import com.mango.products.application.port.out.GetProductPriceRecordPort;
import com.mango.products.domain.model.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Service implementation for retrieving the price record of a product. It uses the GetProductPriceRecordPort to fetch the product data from the database.
 */
@Service
@RequiredArgsConstructor
public class GetProductPriceRecordService implements GetProductPriceRecordUseCase {

    private final GetProductPriceRecordPort productPriceRecordPort;

    /**
     * Retrieves the price record of a product by its ID.
     *
     * @param productId The ID of the {@link Product} to retrieve.
     * @return The product with its price record.
     */
    @Override
    public Product getProductPriceRecord(final Long productId) {
        return this.productPriceRecordPort.getProductPriceRecord(productId);
    }
}
