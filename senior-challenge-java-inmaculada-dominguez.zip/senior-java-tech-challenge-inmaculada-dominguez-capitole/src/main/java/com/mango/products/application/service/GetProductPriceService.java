package com.mango.products.application.service;

import com.mango.products.application.port.in.GetProductPriceUseCase;
import com.mango.products.application.port.out.GetProductPricePort;
import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

/**
 * Service implementation for retrieving the price of a product based on its ID and a specific date.
 */
@Service
@RequiredArgsConstructor
public class GetProductPriceService implements GetProductPriceUseCase {

    private final GetProductPricePort productPricePort;

    /**
     * Retrieves the price of a product for a given ID and date.
     *
     * @param id   the ID of the {@link Product}
     * @param date the date for which to retrieve the price
     * @return the price of the product on the specified date
     */
    @Override
    public Price getProductPrice(final Long id, final LocalDate date) {
        return this.productPricePort.getProductPrice(id, date);
    }
}
