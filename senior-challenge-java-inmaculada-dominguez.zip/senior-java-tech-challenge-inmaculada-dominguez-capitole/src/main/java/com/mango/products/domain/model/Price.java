package com.mango.products.domain.model;

import jakarta.annotation.Nullable;
import lombok.*;

import java.time.LocalDate;

/**
 * Represents the price of a product for a given date range.
 */
@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Price {

    private Double priceValue;

    private LocalDate initDate;

    @Nullable
    private LocalDate endDate;
}
