package com.mango.products.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

/**
 * This class represents a product with its price and the date range for which the price is valid.
 */
@Builder
@Getter
@Setter
@ToString
public class PricedProduct {

    private String productName;

    private Double price;

    private LocalDate initDate;

    private LocalDate endDate;
}
