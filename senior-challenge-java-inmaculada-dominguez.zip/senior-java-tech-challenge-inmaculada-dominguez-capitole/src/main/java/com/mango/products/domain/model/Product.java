package com.mango.products.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.web.bind.annotation.BindParam;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a product in the system, including its name, description, and associated prices.
 */
@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Product {

    private Long id;

    private String name;

    private String description;

    @Builder.Default
    private List<Price> prices = new ArrayList<>();

}
