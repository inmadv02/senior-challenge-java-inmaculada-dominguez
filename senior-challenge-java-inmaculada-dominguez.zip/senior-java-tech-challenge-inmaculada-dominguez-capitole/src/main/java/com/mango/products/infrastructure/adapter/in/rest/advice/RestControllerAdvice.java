package com.mango.products.infrastructure.adapter.in.rest.advice;

import com.mango.products.infrastructure.adapter.in.rest.dto.error.ErrorObjectDTO;
import com.mango.products.infrastructure.adapter.out.persistence.exception.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class RestControllerAdvice {

    @ExceptionHandler(ProductNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorObjectDTO> handleProductNotFoundException(final ProductNotFoundException exception) {
        final var body = createErrorObjectDTO(exception, HttpStatus.NOT_FOUND);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    @ExceptionHandler(PriceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorObjectDTO> handlePriceNotFoundException(final PriceNotFoundException exception) {
        final var body = createErrorObjectDTO(exception, HttpStatus.NOT_FOUND);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    @ExceptionHandler(PriceAlreadyExistsException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorObjectDTO> priceAlreadyExistsException(final PriceAlreadyExistsException exception) {
        final var body = createErrorObjectDTO(exception, HttpStatus.BAD_REQUEST);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    @ExceptionHandler(PricesInitDatesConflictException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorObjectDTO> pricesInitDatesConflictException(final PricesInitDatesConflictException exception) {
        final var body = createErrorObjectDTO(exception, HttpStatus.BAD_REQUEST);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    @ExceptionHandler(EndDateIsOlderThanInitDateException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorObjectDTO> EendDateIsOlderThanInitDateException(final EndDateIsOlderThanInitDateException exception) {
        final var body = createErrorObjectDTO(exception, HttpStatus.BAD_REQUEST);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    private static ErrorObjectDTO createErrorObjectDTO(final Exception exception, final HttpStatus status) {
        return ErrorObjectDTO.builder()
                .title(status.getReasonPhrase())
                .status(status.value())
                .detail(exception.getMessage())
                .build();
    }
}
