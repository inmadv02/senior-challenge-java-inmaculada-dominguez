package com.mango.products.infrastructure.adapter.in.rest.controller;

import com.mango.products.application.service.AddProductPriceService;
import com.mango.products.infrastructure.adapter.in.rest.dto.request.AddProductPriceRequestDTO;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.AddProductPriceResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.request.AddProductPriceRequestDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.AddProductPriceResponseDTOMapper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class AddProductPriceController {

    private final AddProductPriceService addProductPriceService;

    private final AddProductPriceRequestDTOMapper requestDTOMapper;

    private final AddProductPriceResponseDTOMapper responseDTOMapper;

    @PostMapping("/products/{id}/prices")
    public ResponseEntity<AddProductPriceResponseDTO> addProductPrice(
            @PathVariable final Long id, @Valid @RequestBody final AddProductPriceRequestDTO request){
        final var mappedPrice = this.requestDTOMapper.mapRequest(request);
        final var newPrice = this.addProductPriceService.changeProductPrice(id, mappedPrice);
        final var response = this.responseDTOMapper.map(newPrice);

        return ResponseEntity.ok().body(response);
    }
}
