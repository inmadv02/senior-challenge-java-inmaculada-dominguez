package com.mango.products.infrastructure.adapter.in.rest.controller;

import com.mango.products.application.service.CreateProductService;
import com.mango.products.infrastructure.adapter.in.rest.dto.request.CreateProductRequestDTO;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.CreateProductResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.request.CreateProductRequestDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.CreateProductResponseDTOMapper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class CreateProductController {

    private final CreateProductService createProductService;

    private final CreateProductRequestDTOMapper createProductRequestMapper;

    private final CreateProductResponseDTOMapper createProductResponseDTOMapper;

    @PostMapping("/products")
    public ResponseEntity<CreateProductResponseDTO> createProduct(@Valid @RequestBody final CreateProductRequestDTO request){
        final var mappedProduct = this.createProductRequestMapper.mapRequest(request);
        final var newProduct = this.createProductService.createNewProduct(mappedProduct);
        final var response = this.createProductResponseDTOMapper.map(newProduct);

        return ResponseEntity.ok(response);
    }


}
