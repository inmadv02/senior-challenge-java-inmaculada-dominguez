package com.mango.products.infrastructure.adapter.in.rest.controller;

import com.mango.products.application.service.GetProductPriceService;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.GetProductPriceResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.GetProductPriceResponseDTOMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequiredArgsConstructor
public class GetProductPriceController {

    private final GetProductPriceService getProductPriceService;

    private final GetProductPriceResponseDTOMapper getProductPriceResponseDTOMapper;

    @GetMapping("/products/{id}/prices")
    public ResponseEntity<GetProductPriceResponseDTO> getProductPrice(@PathVariable final Long id, @RequestParam LocalDate date){
        final var productPrice = this.getProductPriceService.getProductPrice(id, date);
        final var response = this.getProductPriceResponseDTOMapper.map(productPrice);

        return ResponseEntity.ok(response);
    }
}
