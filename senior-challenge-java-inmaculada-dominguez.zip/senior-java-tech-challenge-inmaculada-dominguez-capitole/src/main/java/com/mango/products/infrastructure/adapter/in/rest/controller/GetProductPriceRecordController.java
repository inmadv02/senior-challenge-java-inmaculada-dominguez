package com.mango.products.infrastructure.adapter.in.rest.controller;

import com.mango.products.application.service.GetProductPriceRecordService;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.GetProductPriceRecordResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.GetProductPriceRecordResponseDTOMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class GetProductPriceRecordController {

    private final GetProductPriceRecordService getProductPriceRecordService;

    private final GetProductPriceRecordResponseDTOMapper getProductPriceRecordResponseDTOMapper;

    @GetMapping("/products/{id}/prices/record")
    public ResponseEntity<GetProductPriceRecordResponseDTO> getByIdProductPriceRecord(@PathVariable final Long id){
        final var productPrice = this.getProductPriceRecordService.getProductPriceRecord(id);
        final var response = this.getProductPriceRecordResponseDTOMapper.map(productPrice);
        return ResponseEntity.ok(response);
    }
}
