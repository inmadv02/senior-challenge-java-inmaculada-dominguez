package com.mango.products.infrastructure.adapter.in.rest.dto.error;

import jakarta.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Builder
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ErrorObjectDTO implements Serializable {

    private Integer status;

    private String title;

    @Nullable
    private String detail;


}
