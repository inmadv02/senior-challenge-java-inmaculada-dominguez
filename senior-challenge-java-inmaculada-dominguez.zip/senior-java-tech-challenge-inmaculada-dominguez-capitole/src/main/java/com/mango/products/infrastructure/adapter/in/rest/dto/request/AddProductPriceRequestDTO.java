package com.mango.products.infrastructure.adapter.in.rest.dto.request;

import jakarta.annotation.Nullable;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddProductPriceRequestDTO {

    @NotNull
    private Double priceValue;

    @NotNull
    private LocalDate initDate;

    @Nullable
    private LocalDate endDate;
}
