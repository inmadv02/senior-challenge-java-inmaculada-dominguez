package com.mango.products.infrastructure.adapter.in.rest.dto.response;

import lombok.Builder;

@Builder(toBuilder = true)
public record CreateProductResponseDTO(Long id, String name, String description){

}
