package com.mango.products.infrastructure.adapter.in.rest.dto.response;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class GetProductPriceRecordResponseDTO {

    private String name;
    private String description;
    private List<PriceDTO> prices;
}
