package com.mango.products.infrastructure.adapter.in.rest.dto.response;

import lombok.Builder;

@Builder(toBuilder = true)
public record GetProductPriceResponseDTO(Double price) {}
