package com.mango.products.infrastructure.adapter.in.rest.dto.response;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PriceDTO {

    private Double price;

    private LocalDate initDate;

    private LocalDate endDate;
}
