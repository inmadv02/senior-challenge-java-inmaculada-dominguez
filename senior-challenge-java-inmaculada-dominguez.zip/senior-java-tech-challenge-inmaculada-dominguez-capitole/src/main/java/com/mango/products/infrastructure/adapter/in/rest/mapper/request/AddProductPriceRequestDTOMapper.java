package com.mango.products.infrastructure.adapter.in.rest.mapper.request;

import com.mango.products.domain.model.Price;
import com.mango.products.infrastructure.adapter.in.rest.dto.request.AddProductPriceRequestDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AddProductPriceRequestDTOMapper {

    Price mapRequest(final AddProductPriceRequestDTO request);

}
