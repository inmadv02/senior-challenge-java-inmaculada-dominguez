package com.mango.products.infrastructure.adapter.in.rest.mapper.request;

import com.mango.products.domain.model.Product;
import com.mango.products.infrastructure.adapter.in.rest.dto.request.CreateProductRequestDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", unmappedTargetPolicy = org.mapstruct.ReportingPolicy.IGNORE)
public interface CreateProductRequestDTOMapper {

    Product mapRequest(final CreateProductRequestDTO request);
}
