package com.mango.products.infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.PricedProduct;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.AddProductPriceResponseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AddProductPriceResponseDTOMapper {

    @Mapping(target = "productName", source = "productName")
    @Mapping(target = "price", source = "price")
    @Mapping(target = "initDate", source = "initDate")
    @Mapping(target = "endDate", source = "endDate")
    AddProductPriceResponseDTO map(PricedProduct pricedProduct);

}
