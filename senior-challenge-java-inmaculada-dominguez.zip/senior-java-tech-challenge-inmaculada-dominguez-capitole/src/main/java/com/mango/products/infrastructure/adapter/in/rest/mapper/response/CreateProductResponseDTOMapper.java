package com.mango.products.infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.Product;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.CreateProductResponseDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CreateProductResponseDTOMapper {

    CreateProductResponseDTO map(final Product product);
}
