package com.mango.products.infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.Product;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.GetProductPriceRecordResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.PriceDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = PriceDTOMapper.class)
public interface GetProductPriceRecordResponseDTOMapper {

    @Mapping(target = "prices", source = "prices")
    GetProductPriceRecordResponseDTO map(Product product);
}
