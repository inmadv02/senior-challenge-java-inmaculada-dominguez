package com.mango.products.infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.Price;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.GetProductPriceResponseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface GetProductPriceResponseDTOMapper {

    @Mapping(target = "price", source = "priceValue")
    GetProductPriceResponseDTO map(final Price price);
}
