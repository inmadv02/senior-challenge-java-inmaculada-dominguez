package com.mango.products.infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.Price;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.PriceDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PriceDTOMapper {

    @Mapping(target = "price", source = "priceValue")
    PriceDTO map(final Price price);
}
