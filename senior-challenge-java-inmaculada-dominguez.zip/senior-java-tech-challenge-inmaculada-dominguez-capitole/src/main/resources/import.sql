-- Products
INSERT INTO product (name, description) VALUES ('T-Shirt Basic', 'Classic cotton t-shirt available in multiple colors');
INSERT INTO product (name, description) VALUES ('Slim Fit Jeans', 'Modern slim fit jeans with stretch fabric');
INSERT INTO product (name, description) VALUES ('Running Sneakers', 'Lightweight sneakers designed for running and training');
INSERT INTO product (name, description) VALUES ('Leather Jacket', 'Premium leather jacket with zip closure');
INSERT INTO product (name, description) VALUES ('Summer Dress', 'Floral print summer dress with adjustable straps');

-- Prices for product 1 (T-Shirt Basic)
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (9.99,  '2025-01-01', '2025-06-30', 1);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (7.99,  '2025-07-01', null, 1);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (8.99,  '2025-11-01', '2025-11-02', 1);

-- Prices for product 2 (Slim Fit Jeans)
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (49.99, '2025-01-01', '2025-03-31', 2);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (39.99, '2025-04-01', '2025-10-31', 2);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (44.99, '2025-05-01', null, 2);

-- Prices for product 3 (Running Sneakers)
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (79.99, '2025-01-01', '2025-12-31', 3);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (89.99, '2025-10-01', '2025-11-01', 3);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (107.95, '2025-11-02', null, 3);

-- Prices for product 4 (Leather Jacket)
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (199.99, '2025-01-01', '2025-09-30', 4);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (179.99, '2025-10-01', null, 4);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (159.99, '2025-11-01', null, 4);

-- Prices for product 5 (Summer Dress)
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (29.99, '2025-03-01', '2025-08-31', 5);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (24.99, '2025-09-01', '2025-10-15', 5);
INSERT INTO price (price_value, init_date, end_date, product_id) VALUES (19.99, '2025-10-16', null, 5);

