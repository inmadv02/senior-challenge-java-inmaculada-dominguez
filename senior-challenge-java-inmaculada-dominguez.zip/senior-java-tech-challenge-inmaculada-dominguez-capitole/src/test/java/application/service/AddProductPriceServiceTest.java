package application.service;

import com.mango.products.application.port.out.AddProductPricePort;
import com.mango.products.application.service.AddProductPriceService;
import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.PricedProduct;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AddProductPriceServiceTest {

    @InjectMocks
    private AddProductPriceService addProductPriceService;

    @Mock
    private AddProductPricePort addProductPricePort;

    private PricedProduct pricedProduct;

    private Price price;

    @BeforeEach
    void setUp() {
        this.pricedProduct = PricedProduct.builder()
                .productName("Blue Jeans")
                .price(100.0)
                .initDate(LocalDate.now())
                .build();
        this.price = Price.builder()
                .priceValue(100.0)
                .initDate(LocalDate.now())
                .endDate(LocalDate.now().plusDays(40))
                .build();

    }

    @Test
    void when_changeProductPrice_with_valid_id_and_price_without_endDate_then_return_pricedProduct() {
        // GIVEN
        doReturn(this.pricedProduct).when(addProductPricePort).addProductPrice(anyLong(), any(Price.class));

        // WHEN
        final var result = this.addProductPriceService.changeProductPrice(1L, this.price);

        // THEN
        assertNotNull(result);
        assertEquals(pricedProduct.getProductName(), result.getProductName());
        assertEquals(pricedProduct.getPrice(), result.getPrice());
        assertEquals(pricedProduct.getInitDate(), result.getInitDate());
        assertNull(result.getEndDate());
        verify(addProductPricePort, times(1)).addProductPrice(anyLong(), any(Price.class));
    }

    @Test
    void when_changeProductPrice_with_valid_id_and_price_with_endDate_then_return_pricedProduct() {
        // GIVEN
        this.pricedProduct.setEndDate(this.pricedProduct.getInitDate().plusDays(40));
        doReturn(this.pricedProduct).when(addProductPricePort).addProductPrice(anyLong(), any(Price.class));

        // WHEN
        final var result = this.addProductPriceService.changeProductPrice(1L, this.price);

        // THEN
        assertNotNull(result);
        assertEquals(this.pricedProduct.getProductName(), result.getProductName());
        assertEquals(this.pricedProduct.getPrice(), result.getPrice());
        assertEquals(this.pricedProduct.getInitDate(), result.getInitDate());
        assertEquals(this.pricedProduct.getEndDate(), result.getEndDate());
        verify(addProductPricePort, times(1)).addProductPrice(anyLong(), any(Price.class));
    }

}
