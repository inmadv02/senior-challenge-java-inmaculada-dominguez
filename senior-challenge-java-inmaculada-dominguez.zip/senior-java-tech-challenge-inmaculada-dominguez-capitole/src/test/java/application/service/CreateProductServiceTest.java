package application.service;

import com.mango.products.application.port.out.CreateProductPort;
import com.mango.products.application.service.CreateProductService;
import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CreateProductServiceTest {

    @InjectMocks
    private CreateProductService createProductService;

    @Mock
    private CreateProductPort createProductPort;

    private Product product;

    @BeforeEach
    void setUp() {
        this.product = Product.builder()
                .id(1L)
                .name("Blue Jeans")
                .description("Classic blue denim jeans")
                .build();
    }

    @Test
    void when_createNewProduct_with_valid_product_then_return_saved_product() {
        // GIVEN
        when(createProductPort.saveProduct(any(Product.class))).thenReturn(this.product);

        // WHEN
        final Product result = createProductService.createNewProduct(this.product);

        // THEN
        assertNotNull(result);
        assertEquals(this.product.getId(), result.getId());
        assertEquals(this.product.getName(), result.getName());
        assertEquals(this.product.getDescription(), result.getDescription());
        verify(createProductPort, times(1)).saveProduct(any(Product.class));
    }

    @Test
    void when_createNewProduct_with_product_with_prices_then_return_saved_product_with_empty_prices() {
        // GIVEN
        this.product.setPrices(List.of(
                Price.builder()
                        .priceValue(19.99)
                        .initDate(LocalDate.of(2026, 1, 1))
                        .endDate(LocalDate.of(2026, 6, 30))
                        .build(),
                Price.builder()
                        .priceValue(24.99)
                        .initDate(LocalDate.of(2026, 7, 1))
                        .build()
        ));

        when(createProductPort.saveProduct(any(Product.class))).thenReturn(this.product);

        // WHEN
        final Product result = createProductService.createNewProduct(this.product);

        // THEN
        assertNotNull(result);
        assertEquals(this.product.getId(), result.getId());
        assertEquals(this.product.getName(), result.getName());
        assertEquals(this.product.getDescription(), result.getDescription());
        assertEquals(2, result.getPrices().size());
        verify(createProductPort, times(1)).saveProduct(any(Product.class));
    }
}
