package application.service;

import com.mango.products.application.port.out.GetProductPriceRecordPort;
import com.mango.products.application.service.GetProductPriceRecordService;
import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GetProductPriceRecordServiceTest {

    @InjectMocks
    private GetProductPriceRecordService getProductPriceRecordService;

    @Mock
    private GetProductPriceRecordPort productPriceRecordPort;

    private Product product;

    @BeforeEach
    void setUp() {
        this.product = Product.builder()
                .id(1L)
                .name("Blue Jeans")
                .description("Classic blue denim jeans")
                .prices(List.of())
                .build();
    }

    @Test
    void when_getProductPriceRecord_with_valid_id_then_return_product() {
        // GIVEN
        when(productPriceRecordPort.getProductPriceRecord(anyLong())).thenReturn(this.product);

        // WHEN
        final var result = getProductPriceRecordService.getProductPriceRecord(anyLong());

        // THEN
        assertNotNull(result);
        assertEquals(this.product.getId(), result.getId());
        assertEquals(this.product.getName(), result.getName());
        assertEquals(this.product.getDescription(), result.getDescription());
        verify(productPriceRecordPort, times(1)).getProductPriceRecord(anyLong());
    }

    @Test
    void when_getProductPriceRecord_with_valid_id_and_prices_then_return_product_with_prices() {
        // GIVEN
        final var productWithPrices = Product.builder()
                .id(1L)
                .name("Blue Jeans")
                .description("Classic blue denim jeans")
                .prices(List.of(
                        Price.builder().priceValue(100.0).initDate(LocalDate.now()).build(),
                        Price.builder().priceValue(150.0).initDate(LocalDate.now().plusDays(30)).build()
                ))
                .build();

        when(productPriceRecordPort.getProductPriceRecord(anyLong())).thenReturn(productWithPrices);

        // WHEN
        final var result = getProductPriceRecordService.getProductPriceRecord(anyLong());

        // THEN
        assertNotNull(result);
        assertEquals(2, result.getPrices().size());
        verify(productPriceRecordPort, times(1)).getProductPriceRecord(anyLong());
    }

}
