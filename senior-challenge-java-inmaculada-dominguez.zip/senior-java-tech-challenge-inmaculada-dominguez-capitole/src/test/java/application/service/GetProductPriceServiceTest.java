package application.service;

import com.mango.products.application.port.out.GetProductPricePort;
import com.mango.products.application.service.GetProductPriceService;
import com.mango.products.domain.model.Price;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GetProductPriceServiceTest {

    @InjectMocks
    private GetProductPriceService getProductPriceService;

    @Mock
    private GetProductPricePort productPricePort;

    private Price price;

    private LocalDate initDate;

    @BeforeEach
    void setUp() {
        this.initDate = LocalDate.now();
        this.price = Price.builder()
                .priceValue(100.0)
                .initDate(this.initDate)
                .build();
    }

    @Test
    void when_getProductPrice_with_valid_id_and_date_then_return_price() {
        // GIVEN
        when(productPricePort.getProductPrice(anyLong(), any(LocalDate.class))).thenReturn(this.price);

        // WHEN
        final Price result = getProductPriceService.getProductPrice(1L, this.initDate);

        // THEN
        assertNotNull(result);
        assertEquals(this.price.getPriceValue(), result.getPriceValue());
        assertEquals(this.price.getInitDate(), result.getInitDate());
        assertNull(result.getEndDate());
        verify(productPricePort, times(1)).getProductPrice(anyLong(), any(LocalDate.class));
    }

    @Test
    void when_getProductPrice_with_valid_id_and_date_with_endDate_then_return_price() {
        // GIVEN
        this.price.setEndDate(this.initDate.plusDays(30));
        when(productPricePort.getProductPrice(anyLong(), any(LocalDate.class))).thenReturn(this.price);

        // WHEN
        final Price result = getProductPriceService.getProductPrice(1L, this.initDate);

        // THEN
        assertNotNull(result);
        assertEquals(this.price.getPriceValue(), result.getPriceValue());
        assertEquals(this.price.getInitDate(), result.getInitDate());
        assertEquals(this.price.getEndDate(), result.getEndDate());
        verify(productPricePort, times(1)).getProductPrice(anyLong(), any(LocalDate.class));
    }

    @Test
    void when_getProductPrice_then_delegate_to_port_exactly_once() {
        // GIVEN
        when(productPricePort.getProductPrice(anyLong(), any(LocalDate.class))).thenReturn(this.price);

        // WHEN
        getProductPriceService.getProductPrice(1L, this.initDate);

        // THEN
        verify(productPricePort, times(1)).getProductPrice(anyLong(), any(LocalDate.class));
        verifyNoMoreInteractions(productPricePort);
    }
}
