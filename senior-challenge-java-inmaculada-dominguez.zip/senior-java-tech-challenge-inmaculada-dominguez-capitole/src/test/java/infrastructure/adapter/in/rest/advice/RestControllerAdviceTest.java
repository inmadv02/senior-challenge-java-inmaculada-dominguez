package infrastructure.adapter.in.rest.advice;

import com.mango.products.infrastructure.adapter.in.rest.advice.RestControllerAdvice;
import com.mango.products.infrastructure.adapter.in.rest.dto.error.ErrorObjectDTO;
import com.mango.products.infrastructure.adapter.out.persistence.exception.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class RestControllerAdviceTest {

    @InjectMocks
    RestControllerAdvice restControllerAdvice;

    @Test
    void when_call_handleProductNotFoundException_then_return_as_expected() {
        // GIVEN
        final ProductNotFoundException productNotFoundException = new ProductNotFoundException("Product not found with id: 123");

        // WHEN
        final ResponseEntity<ErrorObjectDTO> response = this.restControllerAdvice.handleProductNotFoundException(productNotFoundException);

        // VERIFY
        final ErrorObjectDTO errorBody = response.getBody();

        assertNotNull(response);
        assertNotNull(errorBody);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatusCode().value());
        assertEquals(HttpStatus.NOT_FOUND.getReasonPhrase(), errorBody.getTitle());
        assertEquals("Product not found with id: 123", errorBody.getDetail());

    }

    @Test
    void when_call_handlePriceNotFoundException_then_return_as_expected() {
        // GIVEN
        final PriceNotFoundException productNotFoundException = new PriceNotFoundException("Price not found with id: 234");

        // WHEN
        final ResponseEntity<ErrorObjectDTO> response = this.restControllerAdvice.handlePriceNotFoundException(productNotFoundException);

        // VERIFY
        final ErrorObjectDTO errorBody = response.getBody();

        assertNotNull(response);
        assertNotNull(errorBody);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatusCode().value());
        assertEquals(HttpStatus.NOT_FOUND.getReasonPhrase(), errorBody.getTitle());
        assertEquals("Price not found with id: 234", errorBody.getDetail());

    }

    @Test
    void when_call_priceAlreadyExistsException_then_return_as_expected() {
        // GIVEN
        final PriceAlreadyExistsException priceAlreadyExistsException = new PriceAlreadyExistsException("Price already exists for product: 456");

        // WHEN
        final ResponseEntity<ErrorObjectDTO> response = this.restControllerAdvice.priceAlreadyExistsException(priceAlreadyExistsException);

        // VERIFY
        final ErrorObjectDTO errorBody = response.getBody();

        assertNotNull(response);
        assertNotNull(errorBody);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode().value());
        assertEquals(HttpStatus.BAD_REQUEST.getReasonPhrase(), errorBody.getTitle());
        assertEquals("Price already exists for product: 456", errorBody.getDetail());
    }

    @Test
    void when_call_ricesInitDatesConflictException_then_return_as_expected() {
        // GIVEN
        final PricesInitDatesConflictException pricesInitDatesConflictException =
                new PricesInitDatesConflictException("Init dates conflict for price range: 2026-01-01 to 2026-12-31");

        // WHEN
        final ResponseEntity<ErrorObjectDTO> response = this.restControllerAdvice.pricesInitDatesConflictException(pricesInitDatesConflictException);

        // VERIFY
        final ErrorObjectDTO errorBody = response.getBody();

        assertNotNull(response);
        assertNotNull(errorBody);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode().value());
        assertEquals(HttpStatus.BAD_REQUEST.getReasonPhrase(), errorBody.getTitle());
        assertEquals("Init dates conflict for price range: 2026-01-01 to 2026-12-31",  errorBody.getDetail());
    }

    @Test
    void when_call_EendDateIsOlderThanInitDateException_then_return_as_expected() {
        // GIVEN
        final EndDateIsOlderThanInitDateException endDateIsOlderThanInitDateException =
                new EndDateIsOlderThanInitDateException("End date 2026-01-01 is older than init date 2026-12-31");

        // WHEN
        final ResponseEntity<ErrorObjectDTO> response = this.restControllerAdvice.EendDateIsOlderThanInitDateException(endDateIsOlderThanInitDateException);

        // VERIFY
        final ErrorObjectDTO errorBody = response.getBody();

        assertNotNull(response);
        assertNotNull(errorBody);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode().value());
        assertEquals(HttpStatus.BAD_REQUEST.getReasonPhrase(), errorBody.getTitle());
        assertEquals("End date 2026-01-01 is older than init date 2026-12-31", errorBody.getDetail());
    }


}