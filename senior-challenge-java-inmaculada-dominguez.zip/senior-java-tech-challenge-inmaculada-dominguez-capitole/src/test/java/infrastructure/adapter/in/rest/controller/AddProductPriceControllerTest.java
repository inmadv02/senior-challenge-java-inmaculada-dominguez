package infrastructure.adapter.in.rest.controller;

import com.mango.products.application.service.AddProductPriceService;
import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.PricedProduct;
import com.mango.products.infrastructure.adapter.in.rest.controller.AddProductPriceController;
import com.mango.products.infrastructure.adapter.in.rest.dto.request.AddProductPriceRequestDTO;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.AddProductPriceResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.request.AddProductPriceRequestDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.AddProductPriceResponseDTOMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AddProductPriceControllerTest {

    @InjectMocks
    private AddProductPriceController addProductPriceController;

    @Mock
    private AddProductPriceService addProductPriceService;

    @Mock
    private AddProductPriceRequestDTOMapper requestDTOMapper;

    @Mock
    private AddProductPriceResponseDTOMapper responseDTOMapper;

    private AddProductPriceRequestDTO requestDTO;
    private Price price;
    private PricedProduct pricedProduct;
    private AddProductPriceResponseDTO responseDTO;

    @BeforeEach
    void setUp() {
        this.requestDTO = AddProductPriceRequestDTO.builder()
                .priceValue(100.0)
                .initDate(LocalDate.now())
                .build();

        this.price = Price.builder()
                .priceValue(250.0)
                .initDate(LocalDate.now())
                .build();

        this.pricedProduct = PricedProduct.builder()
                .productName("Mary Janes")
                .price(250.0)
                .initDate(LocalDate.now())
                .build();

        this.responseDTO = AddProductPriceResponseDTO.builder()
                .productName(this.pricedProduct.getProductName())
                .price(250.0)
                .initDate(LocalDate.now())
                .build();
    }

    @Test
    void when_call_addProductPrice_with_valid_id_and_request_then_return_200_with_response() {
        // GIVEN
        when(this.requestDTOMapper.mapRequest(any(AddProductPriceRequestDTO.class))).thenReturn(this.price);
        when(this.addProductPriceService.changeProductPrice(anyLong(), any(Price.class))).thenReturn(this.pricedProduct);
        when(this.responseDTOMapper.map(any(PricedProduct.class))).thenReturn(this.responseDTO);

        // WHEN
        final var result = this.addProductPriceController.addProductPrice(1L, this.requestDTO);

        // THEN
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(this.responseDTO.getProductName(), result.getBody().getProductName());
        assertEquals(this.responseDTO.getPrice(), result.getBody().getPrice());
        assertEquals(this.responseDTO.getInitDate(), result.getBody().getInitDate());

        final var inOrder = inOrder(this.requestDTOMapper, this.addProductPriceService, this.responseDTOMapper);
        inOrder.verify(this.requestDTOMapper, times(1)).mapRequest(any(AddProductPriceRequestDTO.class));
        inOrder.verify(this.addProductPriceService, times(1)).changeProductPrice(anyLong(), any(Price.class));
        inOrder.verify(this.responseDTOMapper, times(1)).map(any(PricedProduct.class));
        inOrder.verifyNoMoreInteractions();
    }

    @Test
    void when_call_addProductPrice_with_valid_id_and_request_with_endDate_then_return_200_with_response() {
        // GIVEN
        final LocalDate endDate = LocalDate.now().plusDays(30);
        this.requestDTO.setEndDate(endDate);
        this.responseDTO.setEndDate(endDate);

        when(this.requestDTOMapper.mapRequest(any(AddProductPriceRequestDTO.class))).thenReturn(this.price);
        when(this.addProductPriceService.changeProductPrice(anyLong(), any(Price.class))).thenReturn(this.pricedProduct);
        when(this.responseDTOMapper.map(any(PricedProduct.class))).thenReturn(this.responseDTO);

        // WHEN
        final var result = this.addProductPriceController.addProductPrice(1L, this.requestDTO);

        // THEN
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(endDate, result.getBody().getEndDate());

        final var inOrder = inOrder(this.requestDTOMapper, this.addProductPriceService, this.responseDTOMapper);
        inOrder.verify(this.requestDTOMapper, times(1)).mapRequest(any(AddProductPriceRequestDTO.class));
        inOrder.verify(this.addProductPriceService, times(1)).changeProductPrice(anyLong(), any(Price.class));
        inOrder.verify(this.responseDTOMapper, times(1)).map(any(PricedProduct.class));
        inOrder.verifyNoMoreInteractions();
    }

}