package infrastructure.adapter.in.rest.controller;

import com.mango.products.application.service.CreateProductService;
import com.mango.products.domain.model.Product;
import com.mango.products.infrastructure.adapter.in.rest.controller.CreateProductController;
import com.mango.products.infrastructure.adapter.in.rest.dto.request.CreateProductRequestDTO;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.CreateProductResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.request.CreateProductRequestDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.CreateProductResponseDTOMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CreateProductControllerTest {

    @InjectMocks
    private CreateProductController createProductController;

    @Mock
    private CreateProductService createProductService;

    @Mock
    private CreateProductRequestDTOMapper createProductRequestMapper;

    @Mock
    private CreateProductResponseDTOMapper createProductResponseDTOMapper;

    private CreateProductRequestDTO requestDTO;
    private Product product;
    private CreateProductResponseDTO responseDTO;

    @BeforeEach
    void setUp() {
        this.requestDTO = CreateProductRequestDTO.builder()
                .name("Blue Jeans")
                .description("Jeans description")
                .build();

        this.product = Product.builder()
                .id(1L)
                .name("Blue Jeans")
                .description("Jeans description")
                .build();

        this.responseDTO = new CreateProductResponseDTO(product.getId(), product.getName(), product.getDescription());
    }

    @Test
    void when_call_createProduct_with_valid_request_then_return_200_with_response() {
        // GIVEN
        when(this.createProductRequestMapper.mapRequest(any(CreateProductRequestDTO.class))).thenReturn(this.product);
        when(this.createProductService.createNewProduct(any(Product.class))).thenReturn(this.product);
        when(this.createProductResponseDTOMapper.map(any(Product.class))).thenReturn(this.responseDTO);

        // WHEN
        final var result = this.createProductController.createProduct(this.requestDTO);

        // THEN
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(this.responseDTO.id(), result.getBody().id());
        assertEquals(this.responseDTO.name(), result.getBody().name());
        assertEquals(this.responseDTO.description(), result.getBody().description());

        final var inOrder = inOrder(this.createProductRequestMapper, this.createProductService, this.createProductResponseDTOMapper);

        inOrder.verify(this.createProductRequestMapper, times(1)).mapRequest(any(CreateProductRequestDTO.class));
        inOrder.verify(this.createProductService, times(1)).createNewProduct(any(Product.class));
        inOrder.verify(this.createProductResponseDTOMapper, times(1)).map(any(Product.class));
    }
}