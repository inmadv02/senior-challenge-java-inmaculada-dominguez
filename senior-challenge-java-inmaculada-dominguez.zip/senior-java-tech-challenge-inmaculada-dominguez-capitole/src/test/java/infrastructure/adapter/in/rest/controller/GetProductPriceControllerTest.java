package infrastructure.adapter.in.rest.controller;

import com.mango.products.application.service.GetProductPriceService;
import com.mango.products.domain.model.Price;
import com.mango.products.infrastructure.adapter.in.rest.controller.GetProductPriceController;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.GetProductPriceResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.GetProductPriceResponseDTOMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GetProductPriceControllerTest {

    @InjectMocks
    private GetProductPriceController getProductPriceController;

    @Mock
    private GetProductPriceService getProductPriceService;

    @Mock
    private GetProductPriceResponseDTOMapper getProductPriceResponseDTOMapper;

    private Price price;
    private GetProductPriceResponseDTO responseDTO;
    private LocalDate date;

    @BeforeEach
    void setUp() {
        this.date = LocalDate.now();
        this.price = Price.builder()
                .priceValue(100.0)
                .initDate(this.date)
                .build();
        this.responseDTO = GetProductPriceResponseDTO.builder()
                .price(100.0)
                .build();
    }

    @Test
    void when_call_getProductPrice_with_valid_id_and_date_then_return_200_with_response() {
        // GIVEN
        when(this.getProductPriceService.getProductPrice(anyLong(), any(LocalDate.class))).thenReturn(this.price);
        when(this.getProductPriceResponseDTOMapper.map(any(Price.class))).thenReturn(this.responseDTO);

        // WHEN
        final var result = this.getProductPriceController.getProductPrice(1L, this.date);

        // THEN
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(this.responseDTO.price(), result.getBody().price());

        final var inOrder = inOrder(this.getProductPriceService, this.getProductPriceResponseDTOMapper);
        inOrder.verify(this.getProductPriceService, times(1)).getProductPrice(anyLong(), any(LocalDate.class));
        inOrder.verify(this.getProductPriceResponseDTOMapper, times(1)).map(any(Price.class));
        inOrder.verifyNoMoreInteractions();
    }

}