package infrastructure.adapter.in.rest.controller;

import com.mango.products.application.service.GetProductPriceRecordService;
import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.Product;
import com.mango.products.infrastructure.adapter.in.rest.controller.GetProductPriceRecordController;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.GetProductPriceRecordResponseDTO;
import com.mango.products.infrastructure.adapter.in.rest.dto.response.PriceDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.GetProductPriceRecordResponseDTOMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GetProductPriceRecordControllerTest {

    @InjectMocks
    private GetProductPriceRecordController getProductPriceRecordController;

    @Mock
    private GetProductPriceRecordService getProductPriceRecordService;

    @Mock
    private GetProductPriceRecordResponseDTOMapper getProductPriceResponseDTOMapper;

    private Product product;
    private GetProductPriceRecordResponseDTO responseDTO;

    @BeforeEach
    void setUp() {
        this.product = Product.builder()
                .id(1L)
                .name("Summer dress")
                .description("Summer dress with flower pattern")
                .prices(List.of(Price.builder().priceValue(40.0).initDate(LocalDate.now()).build()))
                .build();

        this.responseDTO = GetProductPriceRecordResponseDTO.builder()
                .name("Summer dress")
                .description("Summer dress with flower pattern")
                .prices(List.of(PriceDTO.builder().price(40.0).initDate(LocalDate.now()).build()))
                .build();
    }

    @Test
    void when_call_getByIdProductPriceRecord_with_valid_id_then_return_200_with_response() {
        // GIVEN
        when(this.getProductPriceRecordService.getProductPriceRecord(anyLong())).thenReturn(this.product);
        when(this.getProductPriceResponseDTOMapper.map(any(Product.class))).thenReturn(this.responseDTO);

        // WHEN
        final var result = this.getProductPriceRecordController.getByIdProductPriceRecord(1L);

        // THEN
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(this.responseDTO.getName(), result.getBody().getName());
        assertEquals(this.responseDTO.getDescription(), result.getBody().getDescription());
        assertEquals(this.responseDTO.getPrices().size(), result.getBody().getPrices().size());

        final var inOrder = inOrder(this.getProductPriceRecordService, this.getProductPriceResponseDTOMapper);
        inOrder.verify(this.getProductPriceRecordService, times(1)).getProductPriceRecord(anyLong());
        inOrder.verify(this.getProductPriceResponseDTOMapper, times(1)).map(any(Product.class));
        inOrder.verifyNoMoreInteractions();
    }

    @Test
    void when_call_getProductPriceRecord_with_ById_product_without_prices_then_return_200_with_empty_prices() {
        // GIVEN
        this.product.setPrices(List.of());
        this.responseDTO.setPrices(List.of());

        when(this.getProductPriceRecordService.getProductPriceRecord(anyLong())).thenReturn(this.product);
        when(this.getProductPriceResponseDTOMapper.map(any(Product.class))).thenReturn(this.responseDTO);

        // WHEN
        final var result = this.getProductPriceRecordController.getByIdProductPriceRecord(1L);

        // THEN
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(0, result.getBody().getPrices().size());

        final var inOrder = inOrder(this.getProductPriceRecordService, this.getProductPriceResponseDTOMapper);
        inOrder.verify(this.getProductPriceRecordService, times(1)).getProductPriceRecord(anyLong());
        inOrder.verify(this.getProductPriceResponseDTOMapper, times(1)).map(any(Product.class));
        inOrder.verifyNoMoreInteractions();
    }

}