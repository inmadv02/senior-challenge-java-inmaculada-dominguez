package infrastructure.adapter.in.rest.mapper.request;

import com.mango.products.infrastructure.adapter.in.rest.dto.request.AddProductPriceRequestDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.request.AddProductPriceRequestDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.request.AddProductPriceRequestDTOMapperImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = AddProductPriceRequestDTOMapperImpl.class)
class AddProductPriceRequestDTOMapperIT {

    @Autowired
    private AddProductPriceRequestDTOMapper addProductPriceRequestDTOMapper;

    @Test
    void when_map_addProductPriceRequestDTO_without_endDate_then_should_return_price_as_expected() {
        // GIVEN
        final var requestDTO = AddProductPriceRequestDTO.builder()
                .priceValue(20.50)
                .initDate(LocalDate.of(2026, 3, 4))
                .build();
        // WHEN
        final var price = addProductPriceRequestDTOMapper.mapRequest(requestDTO);

        // THEN
        final var expectedPrice =
                """
                   Price(priceValue=20.5, initDate=2026-03-04, endDate=null)""";

        assertNotNull(price);
        assertEquals(expectedPrice, price.toString());
    }

    @Test
    void when_map_addProductPriceRequestDTO_with_endDate_then_should_return_price_as_expected() {
        // GIVEN
        final var requestDTO = AddProductPriceRequestDTO.builder()
                .priceValue(20.50)
                .initDate(LocalDate.of(2026, 3, 4))
                .endDate(LocalDate.of(2026, 4, 4))
                .build();
        // WHEN
        final var price = addProductPriceRequestDTOMapper.mapRequest(requestDTO);

        // THEN
        final var expectedPrice =
                """
                   Price(priceValue=20.5, initDate=2026-03-04, endDate=2026-04-04)""";

        assertNotNull(price);
        assertEquals(expectedPrice, price.toString());

    }
}
