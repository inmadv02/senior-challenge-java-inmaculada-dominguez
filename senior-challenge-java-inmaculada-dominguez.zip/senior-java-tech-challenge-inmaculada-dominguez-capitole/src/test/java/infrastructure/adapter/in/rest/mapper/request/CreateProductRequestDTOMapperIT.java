package infrastructure.adapter.in.rest.mapper.request;

import com.mango.products.infrastructure.adapter.in.rest.dto.request.CreateProductRequestDTO;
import com.mango.products.infrastructure.adapter.in.rest.mapper.request.CreateProductRequestDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.request.CreateProductRequestDTOMapperImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = CreateProductRequestDTOMapperImpl.class)
class CreateProductRequestDTOMapperIT {

    @Autowired
    private CreateProductRequestDTOMapper createProductRequestDTOMapper;

    @Test
    void when_map_createProductRequestDTO_with_name_and_description_then_should_return_product_as_expected() {
        // GIVEN
        final var requestDTO = CreateProductRequestDTO.builder()
                .name("Blue Jeans")
                .description("Jeans description")
                .build();

        // WHEN
        final var product = createProductRequestDTOMapper.mapRequest(requestDTO);

        // THEN
        final var expectedPruduct = """
                Product(id=null, name=Blue Jeans, description=Jeans description, prices=[])""";

        assertNotNull(product);
        assertEquals(expectedPruduct, product.toString());

    }

}
