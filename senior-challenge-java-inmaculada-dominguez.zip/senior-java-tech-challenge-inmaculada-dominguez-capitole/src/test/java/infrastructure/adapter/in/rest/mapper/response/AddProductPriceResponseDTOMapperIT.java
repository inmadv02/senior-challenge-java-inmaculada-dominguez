package infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.PricedProduct;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.AddProductPriceResponseDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.AddProductPriceResponseDTOMapperImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = AddProductPriceResponseDTOMapperImpl.class)
class AddProductPriceResponseDTOMapperIT {

    @Autowired
    private AddProductPriceResponseDTOMapper addProductPriceResponseDTOMapper;

    private PricedProduct pricedProduct;

    @BeforeEach
    void setUp() {
        this.pricedProduct = PricedProduct.builder()
                .productName("Blue Jeans")
                .price(29.99)
                .initDate(LocalDate.of(2026, 1, 1))
                .endDate(LocalDate.of(2026, 12, 31))
                .build();
    }

    @Test
    void when_map_pricedProduct_with_all_fields_then_should_return_responseDTO_as_expected() {
        // WHEN
        final var responseDTO = addProductPriceResponseDTOMapper.map(pricedProduct);

        // THEN
        final var expectedResponseDTO  =
                """
                    AddProductPriceResponseDTO(productName=Blue Jeans, price=29.99, initDate=2026-01-01, endDate=2026-12-31)""";

        assertNotNull(responseDTO);
        assertEquals(expectedResponseDTO, responseDTO.toString());
    }

    @Test
    void when_map_pricedProduct_without_endDate_then_should_return_responseDTO_with_null_endDate() {
        // GIVEN
        this.pricedProduct.setEndDate(null);

        // WHEN
        final var responseDTO = addProductPriceResponseDTOMapper.map(pricedProduct);

        // THEN
        final var expectedResponseDTO  =
                """
                    AddProductPriceResponseDTO(productName=Blue Jeans, price=29.99, initDate=2026-01-01, endDate=null)""";

        assertNotNull(responseDTO);
        assertEquals(expectedResponseDTO, responseDTO.toString());
    }
}
