package infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.Product;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.CreateProductResponseDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.CreateProductResponseDTOMapperImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = CreateProductResponseDTOMapperImpl.class)
class CreateProductResponseDTOMapperIT {

    @Autowired
    private CreateProductResponseDTOMapper createProductResponseDTOMapper;

    @Test
    void when_map_product_with_all_fields_then_should_return_createProductResponseDTO_as_expected() {
        // GIVEN
        final var product = Product.builder()
                .id(1L)
                .name("Blue Jeans")
                .description("Jeans description")
                .build();

        // WHEN
        final var responseDTO = createProductResponseDTOMapper.map(product);

        // THEN
        assertNotNull(responseDTO);
        assertEquals(1L, responseDTO.id());
        assertEquals("Blue Jeans", responseDTO.name());
        assertEquals("Jeans description", responseDTO.description());
    }

}
