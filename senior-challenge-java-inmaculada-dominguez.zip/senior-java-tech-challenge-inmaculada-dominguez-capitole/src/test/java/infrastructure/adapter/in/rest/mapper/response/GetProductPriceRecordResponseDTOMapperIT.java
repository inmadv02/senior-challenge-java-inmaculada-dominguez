package infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.Price;
import com.mango.products.domain.model.Product;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.GetProductPriceRecordResponseDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.GetProductPriceRecordResponseDTOMapperImpl;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.PriceDTOMapperImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = {GetProductPriceRecordResponseDTOMapperImpl.class, PriceDTOMapperImpl.class})
class GetProductPriceRecordResponseDTOMapperIT {

    @Autowired
    private GetProductPriceRecordResponseDTOMapper getProductPriceRecordResponseDTOMapper;

    private Product product;

    @BeforeEach
    void setUp() {
        this.product = Product.builder()
                .id(1L)
                .name("Blue Jeans")
                .description("Jeans description")
                .build();
    }

    @Test
    void when_map_product_with_prices_then_should_return_responseDTO_as_expected() {
        // GIVEN
        final var price1 = Price.builder()
                .priceValue(19.99)
                .initDate(LocalDate.of(2026, 1, 1))
                .endDate(LocalDate.of(2026, 6, 30))
                .build();

        final var price2 = Price.builder()
                .priceValue(24.99)
                .initDate(LocalDate.of(2026, 7, 1))
                .build();

        this.product.setPrices(List.of(price1, price2));

        // WHEN
        final var responseDTO = getProductPriceRecordResponseDTOMapper.map(product);

        // THEN
        final var expectedGetProductPriceRecordResponseDTO  =
                """
                    GetProductPriceRecordResponseDTO(name=Blue Jeans, description=Jeans description, prices=[PriceDTO(price=19.99, initDate=2026-01-01, endDate=2026-06-30), PriceDTO(price=24.99, initDate=2026-07-01, endDate=null)])""";

        assertNotNull(responseDTO);
        assertEquals(expectedGetProductPriceRecordResponseDTO, responseDTO.toString());

    }

    @Test
    void when_map_product_without_prices_then_should_return_responseDTO_with_empty_prices() {
        // WHEN
        final var responseDTO = getProductPriceRecordResponseDTOMapper.map(this.product);

        // THEN
        final var expectedGetProductPriceRecordResponseDTO  =
                """
                    GetProductPriceRecordResponseDTO(name=Blue Jeans, description=Jeans description, prices=[])""";

        assertNotNull(responseDTO);
        assertEquals(expectedGetProductPriceRecordResponseDTO, responseDTO.toString());
    }
}
