package infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.Price;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.GetProductPriceResponseDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.GetProductPriceResponseDTOMapperImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = GetProductPriceResponseDTOMapperImpl.class)
class GetProductPriceResponseDTOMapperIT {

    @Autowired
    private GetProductPriceResponseDTOMapper getProductPriceResponseDTOMapper;

    private Price price;

    @BeforeEach
    void setUp() {
        this.price = Price.builder()
                .priceValue(15.99)
                .initDate(LocalDate.of(2026, 1, 1))
                .build();
    }

    @Test
    void when_map_price_with_all_fields_then_should_return_responseDTO_with_price_value() {
        // GIVEN
        this.price.setEndDate(LocalDate.of(2026, 12, 31));

        // WHEN
        final var responseDTO = getProductPriceResponseDTOMapper.map(this.price);

        // THEN
        assertNotNull(responseDTO);
        assertEquals(15.99, responseDTO.price());
    }

    @Test
    void when_map_price_without_endDate_then_should_return_responseDTO_with_price_value() {
        // WHEN
        final var responseDTO = getProductPriceResponseDTOMapper.map(this.price);

        // THEN
        assertNotNull(responseDTO);
        assertEquals(15.99, responseDTO.price());
    }
}
