package infrastructure.adapter.in.rest.mapper.response;

import com.mango.products.domain.model.Price;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.PriceDTOMapper;
import com.mango.products.infrastructure.adapter.in.rest.mapper.response.PriceDTOMapperImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = PriceDTOMapperImpl.class)
class PriceDTOMapperIT {

    @Autowired
    private PriceDTOMapper priceDTOMapper;

    @Test
    void when_map_price_with_all_fields_then_should_return_priceDTO_as_expected() {
        // GIVEN
        final var price = Price.builder()
                .priceValue(29.99)
                .initDate(LocalDate.of(2026, 1, 1))
                .endDate(LocalDate.of(2026, 6, 30))
                .build();

        // WHEN
        final var priceDTO = priceDTOMapper.map(price);

        // THEN
        final var expectedPriceDTO =
                """
                    PriceDTO(price=29.99, initDate=2026-01-01, endDate=2026-06-30)""";

        assertNotNull(priceDTO);
        assertEquals(expectedPriceDTO, priceDTO.toString());
    }

    @Test
    void when_map_price_without_endDate_then_should_return_priceDTO_with_null_endDate() {
        // GIVEN
        final var price = Price.builder()
                .priceValue(14.99)
                .initDate(LocalDate.of(2026, 3, 4))
                .build();

        // WHEN
        final var priceDTO = priceDTOMapper.map(price);

        // THEN
        final var expectedPriceDTO =
                """
                    PriceDTO(price=14.99, initDate=2026-03-04, endDate=null)""";

        assertNotNull(priceDTO);
        assertEquals(expectedPriceDTO, priceDTO.toString());
    }
}
